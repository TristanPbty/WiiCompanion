@echo off
cd /d "%~dp0"
py -3 wiicompanion_checker.py
if errorlevel 1 python wiicompanion_checker.py
pause
