import os
import tkinter as tk
from tkinter import filedialog, messagebox
from pathlib import Path

def choose_sd():
    root = tk.Tk()
    root.withdraw()
    messagebox.showinfo("Wii Companion", "Sélectionne la racine de la carte SD Wii (le dossier qui contient apps).")
    sd = filedialog.askdirectory(title="Choisir la racine de la carte SD")
    if not sd:
        return
    p = Path(sd)
    lines = [f"Carte choisie : {p}", ""]
    apps = p / "apps"
    if apps.is_dir():
        folders = sorted(x for x in apps.iterdir() if x.is_dir())
        valid = []
        for folder in folders:
            if (folder / "boot.dol").is_file():
                valid.append(folder.name)
        lines.append(f"Dossier apps : trouvé ({len(valid)} application(s) avec boot.dol)")
        for name in valid:
            lines.append(f"  • {name}")
        if not valid:
            lines.append("  Aucune application avec boot.dol détectée.")
    else:
        lines.append("ATTENTION : dossier apps introuvable à la racine.")
    lines.append("")
    theme_dir = p / "themes"
    lines.append(f"Dossier themes : {'présent' if theme_dir.is_dir() else 'absent'}")
    lines.append("Note : la présence d'un fichier thème ne prouve pas qu'il est compatible.")
    lines.append("")
    messagebox.showinfo("Wii Companion — sauvegardes", "Sélectionne ensuite le dossier où tu as sauvegardé la NAND sur le PC.")
    backup = filedialog.askdirectory(title="Dossier des sauvegardes NAND (Annuler si aucun)")
    if backup:
        b = Path(backup)
        for filename in ("nand.bin", "keys.bin"):
            f = b / filename
            lines.append(f"{filename} : {'présent' if f.is_file() else 'absent dans ce dossier'}")
        lines.append("Conserve ces fichiers en lieu sûr. Ne partage pas keys.bin.")
    else:
        lines.append("Vérification des sauvegardes ignorée.")
    out = "\n".join(lines)
    win = tk.Toplevel()
    win.title("Wii Companion — rapport")
    win.geometry("680x520")
    txt = tk.Text(win, wrap="word", padx=12, pady=12)
    txt.pack(fill="both", expand=True)
    txt.insert("1.0", out)
    txt.configure(state="disabled")
    tk.Button(win, text="Fermer", command=win.destroy).pack(pady=8)
    win.mainloop()

if __name__ == "__main__":
    choose_sd()
