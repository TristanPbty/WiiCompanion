# Safety notes

- Do not use this app to install themes, WADs, IOS patches, or System Menu files.
- Do not format the SD card as part of troubleshooting.
- Keep `nand.bin` and `keys.bin` private and backed up in more than one safe place.
- A NAND backup is not a guarantee of easy recovery.
- This prototype only checks file presence; it does not verify cryptographic integrity or theme compatibility.
