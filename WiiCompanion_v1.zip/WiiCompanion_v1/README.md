# Wii Companion — prototype v0.1

Wii Companion is a starter project for a classic Wii (Homebrew Channel) plus a Windows SD-card checker.

## What's included
- `wii/`: a small native Wii homebrew app in C using devkitPPC/libogc. It displays basic console/runtime information and scans `sd:/apps/` for app folders.
- `windows/wiicompanion_checker.py`: a Windows-friendly SD card checker. It checks common Homebrew folder structure and reports whether NAND backup files are present in a folder you select. It does not modify the SD card.
- `docs/`: setup and safety notes.

## Important limitations
This is a first prototype, not a finished recovery tool. It does not install themes, change the System Menu, restore NAND, or guarantee recovery from a brick. The Wii app can only report what its APIs expose; it cannot reliably identify every installed theme or all system modifications.

## Build the Wii app
1. Install devkitPro for Windows from https://devkitpro.org/
2. In the devkitPro environment, make sure the Wii/GameCube development group is installed (`devkitPPC`, `libogc`, and the Wii toolchain).
3. Open the `wii` folder in the devkitPro/MSYS2 terminal.
4. Run `make`.
5. The output should be `boot.dol`.
6. Copy the folder `wii/apps/wiicompanion/` to `SD:/apps/wiicompanion/`, keeping `boot.dol`, `meta.xml`, and `icon.png` together.
7. Launch Wii Companion from the Homebrew Channel.

If compilation fails, copy the full error output; don't guess at missing packages.

## Run the Windows checker
Install Python 3 if needed, then double-click `windows/run_checker.bat`, or run:
`python wiicompanion_checker.py`

Select the SD card root and optionally the folder containing `nand.bin` and `keys.bin`. The checker is read-only and never formats or edits files.
