#include <gccore.h>
#include <fat.h>
#include <wiiuse/wpad.h>
#include <ogc/system.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>

static void *xfb = NULL;
static GXRModeObj *rmode = NULL;

static int count_apps(void) {
    DIR *dir = opendir("sd:/apps");
    if (!dir) return -1;
    int count = 0;
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_name[0] == '.') continue;
        char path[256];
        snprintf(path, sizeof(path), "sd:/apps/%s/boot.dol", entry->d_name);
        struct stat st;
        if (stat(path, &st) == 0 && S_ISREG(st.st_mode)) count++;
    }
    closedir(dir);
    return count;
}

int main(void) {
    VIDEO_Init();
    WPAD_Init();
    rmode = VIDEO_GetPreferredMode(NULL);
    xfb = MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));
    console_init(xfb, 20, 20, rmode->fbWidth, rmode->xfbHeight, rmode->fbWidth * VI_DISPLAY_PIX_SZ);
    VIDEO_Configure(rmode);
    VIDEO_SetNextFramebuffer(xfb);
    VIDEO_SetBlack(FALSE);
    VIDEO_Flush();
    VIDEO_WaitVSync();
    if (rmode->viTVMode & VI_NON_INTERLACE) VIDEO_WaitVSync();

    bool sd_ok = fatInitDefault();

    u32 version = IOS_GetVersion();
    int app_count = count_apps();

    while (1) {
        WPAD_ScanPads();
        u32 pressed = WPAD_ButtonsDown(0);

        printf("\x1b[2J");
        printf("\x1b[2;4H========================================\n");
        printf("\x1b[3;4H          WII COMPANION  v0.1\n");
        printf("\x1b[4;4H       Informations de ta Wii\n");
        printf("\x1b[5;4H========================================\n\n");
        printf("  Systeme : Nintendo Wii classique\n");
        printf("  IOS actif : %lu\n", (unsigned long)version);
        printf("  Carte SD : %s\n", sd_ok ? "montee" : "non detectee");
        if (app_count < 0)
            printf("  Applications Homebrew : dossier sd:/apps introuvable\n");
        else
            printf("  Applications detectees : %d\n", app_count);
        printf("\n  Cette version ne modifie aucun parametre systeme.\n");
        printf("\n  Wiimote : HOME pour quitter.\n");
        printf("  Appuie sur A pour actualiser les informations.\n");

        if (pressed & WPAD_BUTTON_HOME) break;
        if (pressed & WPAD_BUTTON_A) {
            app_count = count_apps();
            version = IOS_GetVersion();
        }
        VIDEO_WaitVSync();
    }

    if (sd_ok) fatUnmount("sd");
    return 0;
}
