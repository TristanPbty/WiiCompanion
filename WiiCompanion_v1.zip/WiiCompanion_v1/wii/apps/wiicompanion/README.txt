Build the project in ../.. and copy the generated boot.dol into this folder. Keep meta.xml alongside boot.dol.
